import greenfoot.*;  // (World, Actor, GreenfootImage, Greenfoot and MouseInfo)

/**
 * Write a description of class Ant here.
 * 
 * @author (your name) 
 * @version (a version number or a date)
 */
public class Ant extends Actor
{
    /**
     * Act - do whatever the Ant wants to do. This method is called whenever
     * the 'Act' or 'Run' button gets pressed in the environment.
     */
    public void act()
    {
        setLocation(getX(), getY() +1);
        
        if (getY() == 599) 
        {
            ((Background) getWorld()).gameOver();
        }
    }
    private void smashAnt() {
        //getWorld().removeObject(this);
        GreenfootImage smashedAntImage = new GreenfootImage("sant1.png");
        SmashedAnt smashedAnt = new SmashedAnt();
        smashedAnt.setImage(smashedAntImage);
        getWorld().addObject(smashedAnt, getX(), getY());
        
        //Timer timer = new Timer(60);
        //timer.start();
        //smashedAnt.setTimer(timer);
        //Greenfoot.delay(60);
        //getWorld().removeObject(smashedAnt);
    }
    public void pop() 
    {
        Greenfoot.playSound("smash.wav");
        ((Background) getWorld()).countPop();
        smashAnt();
        getWorld().removeObject(this);
        
    }
}
