import greenfoot.*;  // (World, Actor, GreenfootImage, Greenfoot and MouseInfo)

/**
 * Write a description of class MyWorld here.
 * 
 * @author (your name) 
 * @version (a version number or a date)
 */
public class Background extends World
{
    Counter counter = new Counter("Score: ");
    //private boolean gameOver;
    /**
     * Constructor for objects of class MyWorld.
     * 
     */
    public Background()
    {    
        // Create a new world with 600x400 cells with a cell size of 1x1 pixels.
        super(400, 600, 1); 
        setPaintOrder(ScoreBoard.class, Player.class, Ant.class, Counter.class);

        // Add the initial actors
        populate();

        prepare();
        //gameOver=false;
    }
    public void act() 
    {
        if(Greenfoot.getRandomNumber(600) < 6) {
            addObject(new Ant(), Greenfoot.getRandomNumber(400), 0);   
        }
        if(Greenfoot.getRandomNumber(600) < 6) {
            addObject(new Fly(), Greenfoot.getRandomNumber(400), 0);   
        }
        if(Greenfoot.getRandomNumber(2000) < 6) {
            addObject(new Bee(), Greenfoot.getRandomNumber(400), 0);   
        }
        //if(!gameOver){
        //}
        //else{
          //  displayGameOverImage();
        //}
    }
    public void countPop()
    {
        counter.add(10);
    }
    public void gameOver() 
    {
        addObject(new ScoreBoard(counter.getValue()), getWidth()/2, getHeight()/2);
        Greenfoot.playSound("lost.wav");
        Greenfoot.stop();
        //gameOver=true;
    }
    //private void displayGameOverImage(){
      //  GreenfootImage gameOverImage = new GreenfootImage("bee.png");
        //getBackground().drawImage(gameOverImage, getWidth() / 2 - gameOverImage.getWidth() / 2, getHeight() / 2 - gameOverImage.getHeight() / 2);
    //}
    
    private void populate()
    {
        addObject(new Player(), 200, 300);

        addObject(counter, 90, 530);
    }
    
    private void prepare()
    {
        
    }
}
